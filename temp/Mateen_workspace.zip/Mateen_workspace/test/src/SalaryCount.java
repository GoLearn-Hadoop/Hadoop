import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class SalaryCount {

	public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
		
		
		//0		7369,SMITH,CLERK,34,800
		private Text mykey = new Text();	
		private IntWritable myValue = new IntWritable();	
		
		public void map(LongWritable key, Text value,  Context context)
				throws IOException, InterruptedException {
			/*
		String line = value.toString();
        	String[]  strts = line.split(",");
        	int sal = Integer.parseInt(strts[5]);
        	if(sal>80000) {
        		mykey.set("Count :");
        		myValue.set(strts[0]+" --> "+strts[5]);
        		output.collect(mykey, new IntWritable(1)); */
			

			String line = value.toString();
	        	String  strts[] = line.split(",");
	        	int sal = Integer.parseInt(strts[5]);
	        	if(sal>100000) {
	        		mykey.set(strts[0]);
	        		myValue.set(sal);
	        		context.write(mykey, myValue);
			
			}
		}
	}


	public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
		
		
		public void reduce(Text key, Iterable<IntWritable> values,Context context) throws IOException, InterruptedException {
		
			 int sum = 0;
		      for (IntWritable val : values) {
		    	  sum += val.get();
			}
		      context.write(key, new IntWritable(sum));
			/*int sum = 0;
			while (values.hasNext()) {
				sum += values.next().get();
			}
			output.collect(key, new IntWritable(sum));  
			/*while (values.hasNext()) {
			}
			output.collect(key, new IntWritable(sum));*/
		}
	}
//Count : 6
	
	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Sal_>100000");
		   job.setJarByClass(SalaryCount.class);
		    job.setMapperClass(Map.class);
		    //job.setCombinerClass(IntSumReducer.class);
		    job.setReducerClass(Reduce.class);
		    
		    job.setOutputKeyClass(Text.class);
		    job.setOutputValueClass(IntWritable.class);
		    
		    
		    //Error:   The method addInputPath(JobConf, Path) 
		    //in the type FileInputFormat is not applicable for the arguments (Job, Path)
		    FileInputFormat.addInputPath(job, new Path(args[0]));
		   
		    
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    
		    
		    job.waitForCompletion(true);
		  /*  
		    --------------------------------------------
		
		
		
		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(IntWritable.class);

		conf.setMapperClass(Map.class);
		conf.setReducerClass(Reduce.class);

		conf.setInputFormat(TextInputFormat.class);
		conf.setOutputFormat(TextOutputFormat.class);

		FileInputFormat.setInputPaths(conf, new Path(args[0]));
		FileOutputFormat.setOutputPath(conf, new Path(args[1]));

		JobClient.runJob(conf);
*/
	}
}