import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

//left this program in between need to build


public class Salary {
	

	public class Map extends Mapper<LongWritable, Text, Text,Text> {
		
		//0		7369,SMITH,CLERK,34,8000
		
		private Text myvalue = new Text();	
		private Text mykey = new Text();	
		
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString();
        	String[]  strts = line.split(",");
        	int sal = Integer.parseInt(strts[4]);
        	if(sal>2500) {
        		
           		mykey.set(strts[0]);
           	       		
        		myvalue.set(strts[1]+" --> "+strts[5]);
        		
        		context.write(mykey,myvalue);
			}
  //7369	      	SMITH-->8000
		}
	}
	
	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();
		Job job = new Job(conf, "Display_Salary");

		job.setJarByClass(Salary.class);
		job.setReducerClass(MyReduce.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

	/*	
		conf.setOutputValueClass(Text.class);
		//conf.setNumReduceTasks(0);
		conf.setMapperClass(Map.class);
		conf.setInputFormat(TextInputFormat.class);
		conf.setOutputFormat(TextOutputFormat.class);*/

		MultipleInputs.addInputPath(job, new Path(args[0]),TextInputFormat.class, TxnsMapper.class);
		Path outputPath = new Path(args[1]);

		FileInputFormat.setInputPaths(conf, new Path(args[0]));
		FileOutputFormat.setOutputPath(conf, new Path(args[1]));
		Path outputPath = new Path(args[1]);
		outputPath.getFileSystem(conf).delete(outputPath);
		JobClient.runJob(conf);
	}
}