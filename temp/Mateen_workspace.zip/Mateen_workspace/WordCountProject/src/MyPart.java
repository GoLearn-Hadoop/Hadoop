import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
public class MyPart {

	public class MyMapper extends Mapper<LongWritable, Text, Text, IntWritable>  {

		   public void map(LongWritable key, Text value, Context context)
           throws java.io.IOException, InterruptedException {
     
			String line = value.toString();
			StringTokenizer tokenizer = new StringTokenizer(line);

			while (tokenizer.hasMoreTokens()) {
				value.set(tokenizer.nextToken());
				context.write(value, new IntWritable(1));

				// // I am fine I am fine
				// v
				// I 1
				// am 1
				// fine 1
				// I 1
				// am 1
				// fine 1

				// I (1,1)

			}

		}
	}

	
	
	
	// Output types of Mapper should be same as arguments of Partitioner
	public static class MyPartitioner extends Partitioner<Text, IntWritable> {

		@Override
		public int getPartition(Text key, IntWritable value, int numPartitions) {

			String myKey = key.toString().toLowerCase();

			if (myKey.startsWith("A")|| myKey.startsWith("a")) 
			{
				return 0;  //reducer 1
			}
			else if (myKey.startsWith("B")||myKey.startsWith("b")) 
			{
				return 1;  //reducer 2
			}
			else if (myKey.startsWith("C")||myKey.startsWith("c")) 
			{
				return 2;  //reducer 2
			}
			else if (myKey.startsWith("D")||myKey.startsWith("d")) 
			{
				return 3;  //reducer 2
			}
			else if (myKey.startsWith("E")||myKey.startsWith("e")) 
			{
				return 4;  //reducer 2
			}
			else if (myKey.startsWith("F")||myKey.startsWith("f")) 
			{
				return 5;  //reducer 2
			}
			else if (myKey.startsWith("G")||myKey.startsWith("g")) 
			{
				return 6;  //reducer 2
			}
			else if (myKey.startsWith("H")||myKey.startsWith("h")) 
			{
				return 7;  //reducer 2
			}
			else if (myKey.startsWith("I")||myKey.startsWith("i")) 
			{
				return 8;  //reducer 2
			}
			else if (myKey.startsWith("J")||myKey.startsWith("j")) 
			{
				return 9;  //reducer 2
			}
			else if (myKey.startsWith("K")||myKey.startsWith("k")) 
			{
				return 10;  //reducer 2
			}
			else if (myKey.startsWith("L")||myKey.startsWith("l")) 
			{
				return 11;  //reducer 2
			}
			else if (myKey.startsWith("M")||myKey.startsWith("m")) 
			{
				return 12;  //reducer 2
			}
			else if (myKey.startsWith("N")||myKey.startsWith("n")) 
			{
				return 13;  //reducer 2
			}
			else if (myKey.startsWith("O")||myKey.startsWith("o")) 
			{
				return 14;  //reducer 2
			}
			else if (myKey.startsWith("P")||myKey.startsWith("p")) 
			{
				return 15;  //reducer 2
			}
			else if (myKey.startsWith("Q")||myKey.startsWith("q")) 
			{
				return 16;  //reducer 2
			}
			else if (myKey.startsWith("R")||myKey.startsWith("r")) 
			{
				return 17;  //reducer 2
			}
			else if (myKey.startsWith("S")||myKey.startsWith("s")) 
			{
				return 18;  //reducer 2
			}
			else if (myKey.startsWith("T")||myKey.startsWith("t")) 
			{
				return 19;  //reducer 2
			}
			else if (myKey.startsWith("U")||myKey.startsWith("u")) 
			{
				return 20;  //reducer 2
			}
			else if (myKey.startsWith("V")||myKey.startsWith("v")) 
			{
				return 21;  //reducer 2
			}
			else if (myKey.startsWith("W")||myKey.startsWith("w")) 
			{
				return 22;  //reducer 2
			}
			else if (myKey.startsWith("X")||myKey.startsWith("x")) 
			{
				return 23;  //reducer 2
			}
			else if (myKey.startsWith("Y")||myKey.startsWith("y")) 
			{
				return 24;  //reducer 2
			}
			else if (myKey.startsWith("z")||myKey.startsWith("Z"))
			{
				return 25;  //reducer 3
			}
			else return 26;
		}
		
		
		
		
		
		
//error/*
		public void Configure(JobConf arg0) {

			// Gives you a new instance of JobConf if you want to change Job
			// Configurations

		}
	}
	 public static class MyCombiner extends Reducer<Text,IntWritable,Text,IntWritable> 
	   {
	      private IntWritable result = new IntWritable();
	      public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException 
	      {
	         int sum = 0;
	         for (IntWritable val : values) 
	         {
	            sum += val.get();
	         }
	         result.set(sum);
	         context.write(key, result);
	}

	public static class MyReducer extends Reducer <Text, IntWritable, Text, IntWritable> {
		
		private IntWritable result = new IntWritable();
	      public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException 
	      {
	         int sum = 0;
	         for (IntWritable val : values) 
	         {
	            sum += val.get();
	         }
	         result.set(sum);
	         context.write(key, result);
	}
	}

	
	
	
	
	
	public static void main(String[] args) throws Exception {

	    Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "MyPart");
	    job.setNumReduceTasks(27);	 
	    job.setJarByClass(WordCount.class);
	    job.setMapperClass(MyMap.class);
	    job.setCombinerClass(MyCombiner.class);
	    job.setReducerClass(MyReduce.class);
	    
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	
		
	    job.waitForCompletion(true);
			}
}}