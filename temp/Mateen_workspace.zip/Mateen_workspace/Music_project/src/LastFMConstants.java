
public class LastFMConstants {
public static final int USER_ID = 0;
public static final int TRACK_ID = 1;
public static final int IS_SCROBBLED = 2;
public static final int RADIO = 3;
public static final int IS_SKIPPED = 4;
}